/* 
 * File:   main.cpp
 * Author: Rikki
 * Created on June 22, 2015, 9:32 PM
 * Purpose: First Program to calculate a paycheck
 */

//System Libraries
#include <iostream> //File I/O

using namespace std;
//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables Here
    float hours,rate,pay;
    //Input Values Here
    hours=40.0f;//Hours Worked Units = hours
    rate=1e1f; //Pay Rate      Untis = $'s/hour
    //Process Input Here
    pay=hours*rate;
    //Output Unknowns Here
    cout<<"Hours worked = "<<hours<<"(hrs)"<<endl;
    cout<<"Pay Rate     = $"<<rate<<"/(hrs)"<<endl;
    cout<<"My paycheck  = $"<<pay<<endl;
    return 0;
}

